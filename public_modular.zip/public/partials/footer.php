<footer class="footer">
  <div class="footer-left">
    ¿Tienes preguntas? <a href="ayuda.php">Consigue ayuda aquí →</a>
  </div>
  <div class="footer-right">
    <a href="ayuda.php">Ayuda</a> ·
    <a href="ayuda.php#soporte">Soporte</a> ·
    <a href="ayuda.php#politica">Política</a>
  </div>
  <div class="footer-bottom">
    © <?php echo date('Y'); ?> Descarga Masiva de CFDI.
  </div>
</footer>
